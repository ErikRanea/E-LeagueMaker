package Controlador.ControladoresBD;

public class ControladorTEquipos {
}
