package Controlador.ControladoresBD;

public class ControladorTPatrocinadores {
}
