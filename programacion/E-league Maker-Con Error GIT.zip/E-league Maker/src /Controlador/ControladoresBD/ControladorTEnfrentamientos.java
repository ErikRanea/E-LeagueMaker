package Controlador.ControladoresBD;

public class ControladorTEnfrentamientos {
}
