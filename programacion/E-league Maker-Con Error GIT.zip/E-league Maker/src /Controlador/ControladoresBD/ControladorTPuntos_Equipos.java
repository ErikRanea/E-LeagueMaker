package Controlador.ControladoresBD;

public class ControladorTPuntos_Equipos {
}
