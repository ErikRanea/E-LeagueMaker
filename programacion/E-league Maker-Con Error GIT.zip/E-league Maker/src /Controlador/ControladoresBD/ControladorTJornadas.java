package Controlador.ControladoresBD;

public class ControladorTJornadas {
}
