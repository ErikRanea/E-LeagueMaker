/**
 * Esta clase se encarga de realizar los llamadas a los procedimientos del paquete CRUD que tenemos creado en la base
 * de datos
 */

package Controlador.ControladoresBD;

public class ControladorTUsuarios {

    private Modelo.Usuario usuario;





}
