/**
 * Esta clase se encarga de de controlar los diferentes controlados de la vista.
 * Crea cada uno de los objetos y los interconecta
 *
 * @author Erik
 * @version
 */
package Controlador.ControladoresVista;

public class ControladorVentanas {



}
