import Controlador.ControladorPrincipal;

public class Main {
    public static void main(String[] args)
    {
        ControladorPrincipal con = new ControladorPrincipal();
    }
}